Phase 1 geometry prototype, not print/production release.

Required tools: cad 0.11.18 (build123d integration), agentcad 0.8.1.
Run from the extracted root:
  cad server start
  cad run src/hangul_card.py
  cad run checks/clearance.py
Use the model IDs printed by YOUR run; IDs depend on absolute script path.

Read REVIEW-v02.md for checks, failures and scope. SLA checks fail on
thin features. Wireless charging, electrical function and mechanical
actuation are unverified. Final STEP/STL/GLB follow Phase 1 user review.
